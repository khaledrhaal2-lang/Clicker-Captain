package com.smartcaptain.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private lateinit var distance: EditText
    private lateinit var fare: EditText
    private lateinit var autoSwitch: Switch
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(Color.rgb(8, 13, 22))
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "SmartCaptain"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 72))

        val subtitle = TextView(this).apply {
            text = "مساعد قبول عروض الرحلات"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle)

        autoSwitch = Switch(this).apply {
            text = "القبول التلقائي"
            textSize = 20f
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("enabled", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("enabled", checked).apply()
            }
        }
        root.addView(autoSwitch)

        root.addView(label("أقصى مسافة للوصول للعميل (كم)"))
        distance = numberField(prefs.getFloat("max_distance", 2.5f).toString())
        root.addView(distance)

        root.addView(label("الحد الأدنى لسعر الرحلة (د.أ)"))
        fare = numberField(prefs.getFloat("min_fare", 2.5f).toString())
        root.addView(fare)

        val save = Button(this).apply {
            text = "حفظ الشروط"
            textSize = 18f
            setOnClickListener {
                val d = distance.text.toString().replace(',', '.').toFloatOrNull() ?: 2.5f
                val f = fare.text.toString().replace(',', '.').toFloatOrNull() ?: 2.5f
                prefs.edit().putFloat("max_distance", d).putFloat("min_fare", f).apply()
                Toast.makeText(this@MainActivity, "تم حفظ الشروط", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(save)

        val access = Button(this).apply {
            text = "تفعيل إمكانية الوصول"
            textSize = 17f
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(access)

        val status = TextView(this).apply {
            text = "طريقة العمل:\n" +
                    "✓ يقرأ المسافة والسعر من عرض الرحلة.\n" +
                    "✓ يقارنها بالشروط التي حددتها.\n" +
                    "✓ يقبل فقط العرض المطابق.\n\n" +
                    "مثال: 4.5 كم و 2.00 د.أ مع شرط 2.5 كم و 2.50 د.أ = تجاهل."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 20, 0, 0)
        }
        root.addView(status)

        setContentView(root)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 17f
        setTextColor(Color.LTGRAY)
        setPadding(0, 22, 0, 4)
    }

    private fun numberField(value: String) = EditText(this).apply {
        setText(value)
        textSize = 22f
        setTextColor(Color.WHITE)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }
}
