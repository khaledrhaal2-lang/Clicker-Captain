package com.smartcaptain.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RideAccessibilityService : AccessibilityService() {

    private var lastAcceptedSignature = ""
    private var lastActionAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return

        val root = rootInActiveWindow ?: return
        val allText = collectText(root)

        val distance = Regex("""(?i)(\d+(?:[.,]\d+)?)\s*كم""")
            .find(allText)?.groupValues?.get(1)?.replace(',', '.')?.toFloatOrNull()

        val fare = Regex("""(?i)(?:JOD|دينار|د\.أ)\s*(\d+(?:[.,]\d+)?)""")
            .find(allText)?.groupValues?.get(1)?.replace(',', '.')?.toFloatOrNull()

        if (distance == null || fare == null) return

        val maxDistance = prefs.getFloat("max_distance", 2.5f)
        val minFare = prefs.getFloat("min_fare", 2.5f)

        if (distance <= maxDistance && fare >= minFare) {
            val signature = "%.2f|%.2f".format(distance, fare)
            val now = System.currentTimeMillis()

            // Basic duplicate protection during rapid UI updates.
            if (signature == lastAcceptedSignature && now - lastActionAt < 10_000) return

            if (clickAccept(root)) {
                lastAcceptedSignature = signature
                lastActionAt = now
            }
        }
    }

    private fun collectText(node: AccessibilityNodeInfo): String {
        val out = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            n.text?.let { out.append(' ').append(it) }
            n.contentDescription?.let { out.append(' ').append(it) }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(node)
        return out.toString()
    }

    private fun clickAccept(root: AccessibilityNodeInfo): Boolean {
        val labels = listOf("قبول العرض", "قبول", "Accept offer", "Accept")
        for (label in labels) {
            for (node in root.findAccessibilityNodeInfosByText(label)) {
                if (node.isClickable &&
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

                var parent = node.parent
                repeat(5) {
                    if (parent?.isClickable == true &&
                        parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    parent = parent?.parent
                }
            }
        }
        return false
    }

    override fun onInterrupt() {}
}
